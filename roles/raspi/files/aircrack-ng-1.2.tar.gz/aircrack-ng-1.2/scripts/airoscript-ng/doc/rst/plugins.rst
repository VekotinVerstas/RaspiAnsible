Airoscript plugin system
=========================

Main rules
-----------

* Airoscript plugin system is quite easy to understand.
* Each plugin can modify airoscript's inner behaviour or add a menu entry on plugins' section.
* Each plugin's name corresponds only to its deps, as each plugin can only use ONE external program (but plugins can depend on each other).
