#ifndef VERIFYSSID_H_INCLUDED
#define VERIFYSSID_H_INCLUDED

#include <string.h>

int verifyssid(const unsigned char *s);

#endif // VERIFYSSID_H_INCLUDED
